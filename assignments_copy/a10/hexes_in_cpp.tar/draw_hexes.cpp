// draw_hexes.cpp

#include"hexagon.h"
int main()
{
  for(int i=0; i<6; ++i)
  {
    moveForward();
    turnRightBy(60);
  }
  return 0;
}
