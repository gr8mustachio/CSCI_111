#ifndef HEXAGON_H
#define HEXAGON_H
void moveForward(double inches=0.25);
void moveBackward(double inches=0.25);
void turnRightBy(double deg);
void turnLeftBy(double deg);
#endif
