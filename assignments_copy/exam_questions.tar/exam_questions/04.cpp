//File: 04.cpp
//Correct bug that keeps program from compiling.
//
#include <iostream>

using namespace std;

int main()
{
	float height;
	cin >> height;
  cout << "Height = " << heigt << endl;
	return 0;
}
