//File: 03.cpp
//Correct bug that keeps program from compiling.
//
#include <iostream>

using namespace std;

int main()
{
	float answer;
	cin >> answer >> endl;
  cout << "Answer = " << answer << endl;
	return 0;
}
