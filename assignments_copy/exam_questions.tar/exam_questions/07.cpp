//File: 07.cpp
#include <iostream>

using namespace std;

int main()
{
  string firstname = Robert;
  cout << firstname <<  endl;
	return 0;
}
