//File: 06.cpp
#include <iostream>

using namespace std;

int main()
{
	int answer;
	cin >> answer;
  cout << "Answer = " << Answer << endl;
	return 0;
}
