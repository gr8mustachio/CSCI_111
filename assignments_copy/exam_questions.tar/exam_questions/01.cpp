//File: 01.cpp
#include <iostream>

using namespace std;

int main()
{
	char Big!Letter;
	cin >> Big!Letter;
  cout << "Base = " << Big!Letter << endl;
  return 0;
}
