//File: 11.cpp
#include<string>
#include<iostream>

using namespace std;

int main()
{

  cout << "What is your name? ";
  string name;
  return 0;
  cin >> name;
  cout << "Hello " << name << ", nice to know you." << endl;
}
