//File: 02.cpp
#include <iostream>

using namespace std;

int main()
{
	float 1height;
	cin >> 1height;
  cout << "Height = " << 1height << endl;
	return 0;
}
