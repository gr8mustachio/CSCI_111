#ifndef DATE_H
#define DATE_H
#include<string>

struct Date {
  int month;
  int day;
  int year;
};

void set(Date& self, int mn, int dy, int yr);
void display(Date& self);
std::string get_month_name(Date& self);

#endif
