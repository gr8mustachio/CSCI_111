#ifndef NUMCOLS_H
#define NUMCOLS_H
int get_screen_columns(void);
#endif
