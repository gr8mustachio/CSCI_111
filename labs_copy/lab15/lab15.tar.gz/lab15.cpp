#include<iostream>
#include<iomanip>
#include "Date.h"
#include "Time.h"
using namespace std;
//OTHER FUNCTIONS (none in this case), AND THE MAIN-FUNCTION
int main()
{
  Date d(7,4,1776);
  Time t(12,3);
  d.display();
  t.display();
}
